%This is a MATLAB script
%It can run on my MATLAB_R2013a

%Selected from default.param and imported
% XPEAK_IMAGE as x
% YPEAK_IMAGE as y
% MAG_BEST from sdss-i.cat as i
% MAG_BEST from sdss-g.cat as g

gixy=[g i x y];
gixy=sortrows(gixy,2);%Sort by i ascendingly
j=0;
for k=1:2781;
if gixy(k,2)<19;j=j+1; %Select object with i<19 and store its number in j
end;end;
scatter(gixy(1:j,2),gixy(1:j,1)-gixy(1:j,2),'filled');
gixyc=[gixy(1:j,:) gixy(1:j,1)-gixy(1:j,2)];
gixyc=sortrows(gixyc,-5);%Sort by color descendingly
xy=gixyc(1:20,3:4);%The 20 most reddish objects are printed
xy